<?php  
require_once 'controller/employeeInfo.php';

$employee = fetchEmployee($_GET['id']);


    include "nav.php";



?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<table>
	<tr>
		<th>Name</th>
		<th>Surname</th>
		<th>Username</th>
		<th>Password</th>
		<th>Image</th>
	</tr>
	<tr>
		<td><a href="showEmployee.php?id=<?php echo $employee['ID'] ?>"><?php echo $employee['Name'] ?></a></td>
		<td><?php echo $employee['Surname'] ?></td>
		<td><?php echo $employee['Username'] ?></td>
		<td><?php echo $employee['Password'] ?></td>
		<td><img width="100px" src="uploads/<?php echo $employee['image'] ?>" alt="<?php echo $employee['Name'] ?>"></td>
	</tr>

</table>


</body>
</html>