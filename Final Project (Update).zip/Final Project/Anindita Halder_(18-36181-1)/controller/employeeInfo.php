<?php 

require_once ('model/model.php');

function fetchAllEmployees(){
	return showAllEmployees();

}
function fetchEmployee($id){
	return showEmployee($id);

}
