 <ul>
        <li><a href="addEmployee.php"> Add employee</a></li>
        <li><a href="showAllEmployees.php"> Show all employees</a></li>
        <li><a href="searchUser.php"> Search Employees</a></li>
    </ul>