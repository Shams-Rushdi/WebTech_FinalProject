<?php  
require_once 'controller/studentInfo.php';

$student = fetchStudent($_GET['id']);
include('./header.php');

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

    <fieldset>
    <br>
        <nav>
            Logged in as  <?php echo $_SESSION['User'] ?> ||
            <a href="../controller/logout.php">Log Out</a>
        </nav>
        <br>
    </fieldset>





<table border="1px solid black" width='100%'>

            <td border="1px solid black">
                <label></label>
                <br>
                <hr>
			<?php 
				include "nav.php";

					?>
					
            </td>

<table align="center" border="1px solid black">

	<thead>
	<tr>
		<th>User Profile</th>
		<th>Username</th>
		<th>Email</th>
		<th>Phone Number</th>
		<th>Address</th>
		<th>Salary</th>
		<th>Image</th>
	</tr>
	</thead>
	<tbody>
	<tr>
		<td><a href="showStudent.php?id=<?php echo $student['ID'] ?>"><?php echo $student['Name'] ?></a></td>
		<td><?php echo $student['username'] ?></td>
		<td><?php echo $student['Email'] ?></td>
		<td><?php echo $student['PhoneNumber'] ?></td>
		<td><?php echo $student['Address'] ?></td>
		<td><?php echo $student['Salary'] ?></td>
		
		<td><img width="100px" src="uploads/<?php echo $student['image'] ?>" alt="<?php echo $student['Name'] ?>"></td>
	</tr>
	</tbody>
</table>
</table>


</body>
</html>
<?php include('./footer.php'); ?>