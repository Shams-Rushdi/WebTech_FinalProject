<?php  
require_once 'controller/studentInfo.php';

$students = fetchAllStudents();

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>


        <table border="1px solid black" width='100%'>
        <tr>
            <td border="1px solid black">
                <label></label>
                <br>
                <hr>
			<?php 
				include "nav.php";

					?>
					
            </td>
			
            <td>
                <table align="center" border="1px solid black">
						
<table>
	<thead>
		<tr>
			<th>Name</th>
			<th>Surname</th>
			<th>Username</th>
			<th>Password</th>
			<th>Email</th>
			<th>Phone Number</th>
			<th>Hire Date</th>
			<th>Gender</th>
			<th>Address</th>
			<th>Voter Id Card</th>
			<th>Blood Group</th>
			<th>Salary</th>
			<th>Image</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($students as $i => $student): ?>
			<tr>
				<td><a href="showStudent.php?id=<?php echo $student['ID'] ?>"><?php echo $student['Name'] ?></a></td>
				<td><?php echo $student['Surname'] ?></td>
				<td><?php echo $student['username'] ?></td>
				<td><?php echo $student['password'] ?></td>
				<td><?php echo $student['Email'] ?></td>
				<td><?php echo $student['PhoneNumber'] ?></td>
				<td><?php echo $student['Hire_Date'] ?></td>
				<td><?php echo $student['Gender'] ?></td>
				<td><?php echo $student['Address'] ?></td>
				<td><?php echo $student['VoterIdCard'] ?></td>
				<td><?php echo $student['BloodGroup'] ?></td>
				<td><?php echo $student['Salary'] ?></td>
				
				<td><img width="100px" src="uploads/<?php echo $student['image'] ?>" alt="<?php echo $student['Name'] ?>"></td>
				<td><a href="editStudent.php?id=<?php echo $student['ID'] ?>">Edit</a>&nbsp<a href="controller/deleteStudent.php?id=<?php echo $student['ID'] ?>" onclick="return confirm('Are you sure want to delete this ?')">Delete</a></td>
			</tr>
		<?php endforeach; ?>		
	</tbody>	
</table>
                </table>
                
		</td>
        </tr>
    </table>
</body>
</html>