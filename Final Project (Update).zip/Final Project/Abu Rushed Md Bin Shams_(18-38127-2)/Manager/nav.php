<table border="1px solid black" width='100%'>
        <tr>
            <td border="1px solid black">
                <label>Account</label>
                <br>
                <hr>
                <ul>
        <li><a href="../view/dashboard.php"> DashBoard</a></li>
        <li><a href="addCustomer.php"> Add Employee</a></li>
        <li><a href="showAllStudents.php"> Show all Employee</a></li>
        <li><a href="searchUser.php"> Search Employee</a></li>
                </ul>
            </td>
			
			
        </tr>
    </table>