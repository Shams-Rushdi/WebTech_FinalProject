<?php 

require_once 'controller/studentInfo.php';
$student = fetchStudent($_GET['id']);

 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
        <table border="1px solid black" width='100%'>
        <tr>
            <td border="1px solid black">
                
                <br>
                <hr>
			<?php 
				include "nav.php";

					?>
					
            </td>
			
            <td>
                <table align="center" border="1px solid black">
						
 <form action="controller/updateStudent.php" method="POST" enctype="multipart/form-data">
  <label for="name">Name:</label><br>
  <input value="<?php echo $student['username'] ?>" type="text" id="name" name="name"><br>
  <label for="email">Email:</label><br>
  <input value="<?php echo $student['Email'] ?>" type="text" id="email" name="email"><br>
  <label for="phoneNumber">Phone Number:</label><br>
  <input value="<?php echo $student['PhoneNumber'] ?>" type="text" id="phoneNumber" name="phoneNumber"><br>
  
  <label for="address">Address:</label><br>
  <input value="<?php echo $student['Address'] ?>" type="text" id="address" name="address"><br>
  
  <label for="salary">Salary:</label><br>
  <input value="<?php echo $student['Salary'] ?>" type="text" id="salary" name="salary"><br>
  
  <input type="file" name="image"><br><br>
  <input type="hidden" name="id" value="<?php echo $_GET['id'] ?>">
  <input type="submit" name = "updateStudent" value="Update">
  <input type="reset"> 
</form>  

                </table>
                
            </td>
        </tr>
    </table>
</body>
</html>

