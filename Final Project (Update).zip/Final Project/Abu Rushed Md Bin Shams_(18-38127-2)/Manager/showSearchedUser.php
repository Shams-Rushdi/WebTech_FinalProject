<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
		table,td,th{
			border:1px solid black;
		}
	</style>
</head>
<body>
        <table border="1px solid black" width='100%'>
        <tr>                
                <br>
                <hr>        
            <td border="1px solid black">
                <label>Account</label>
                <br>
                <hr>
                <ul>
				<li><a href="../addCustomer.php"> Add Employee</a></li>
				<li><a href="../showAllStudents.php"> Show all Employee</a></li>
				<li><a href="../searchUser.php"> Search Employee</a></li>
                </ul>
            </td>
			
			        				
<td>
	 <table align="center" border="1px solid black">						
		<thead>
			<tr>
				<th>User_id</th>
				<th>User_name</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
		
			<?php foreach ($allSearchedUsers as $i => $user): ?>
				<tr>
					<td><a href="../showStudent.php?id=<?php echo $user['ID'] ?>"><?php echo $user['ID'] ?></a></td>
					<td><?php echo $user['username'] ?></td>
					<td><a href="../editStudent.php?id=<?php echo $user['ID'] ?>">Edit</a>&nbsp<a href="deleteStudent.php?id=<?php echo $user['ID'] ?>">Delete</a></td>
				</tr>
			<?php endforeach; ?>
			

		</tbody>
					</table>                
	</td>
			</tr>
		</table>


</body>
</html>