<?php include('header.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	
<script>
function validateForm() {
let x = document.forms["myForm"]["name"].value;
if (x.length < 6) {
alert("Name must be filled out");
document.getElementById("text").innerHTML = "Name must be filled out";
document.getElementById("text").style.color="red";
return false;
}
else{
document.getElementById("text").innerHTML = x;
document.getElementById("text").style.color="black";
}
}
function en(){
document.getElementById("btn").disabled = false;

if (document.getElementById("name").value == "" || document.getElementById("surname").value == ""|| document.getElementById("username").value == ""|| document.getElementById("email").value == ""|| document.getElementById("phoneNumber").value == ""|| document.getElementById("password").value == "") {
document.getElementById("btn").disabled = true;
}

}
</script>
</head>
<body>


        <table border="1px solid black" width='100%'>
        <tr>
            <td border="1px solid black">
                
                <br>
                <hr>
			<?php 
				include "nav.php";
			?>
			</td>	
            <td>
 <table align="center" border="1px solid black">						
 <form name="myForm" action="controller/createCustomer.php" onsubmit="return validateForm()" method="POST" enctype="multipart/form-data">
  <label for="name">First Name:</label><br>
  <input type="text" id="name" name="name" onkeyup="en()"><br>
  <label for="surname">Lust Name:</label><br>
  <input type="text" id="surname" name="surname" onkeyup="en()"><br>
  <label for="username">User Name:</label><br>
  <input type="text" id="username" name="username" onkeyup="en()"><br>
  <label for="email">Email:</label><br>
  <input type="text" id="email" name="email" onkeyup="en()"><br>
  <label for="phoneNumber">Phone Number:</label><br>
  <input type="text" id="phoneNumber" name="phoneNumber" onkeyup="en()"><br>
  <label for="password">Password:</label><br>
  <input type="password" id="password" name="password" onkeyup="en()"><br>
  <label for="img">Image:</label><br>
  <input type="file" name="image"><br><br>
  <input id="btn" type="submit" name = "createCustomer" value="Create" disabled>
  <input type="reset"> 
</form> 
                </table>                
            </td>
        </tr>
    </table>
</body>
</html>
<?php include('footer.php'); ?> 

