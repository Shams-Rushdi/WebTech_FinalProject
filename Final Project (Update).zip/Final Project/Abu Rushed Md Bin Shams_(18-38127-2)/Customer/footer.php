<fieldset>
    <center>
        <b>
            <label>
                Copyright © 2021
            </label>
        </b>
    </center>
</fieldset>