<fieldset>
    <table>
        <tr>
            <td>
                <img src="../images/icon.png" alt="Image not available" height="80">
            </td>
            <td>
                <h2></h2>
            </td>
            <td></td>
        </tr>
    </table>    
</fieldset>