<?php 

require_once 'controller/studentInfo.php';
$student = fetchStudent($_GET['id']);

 ?>
 <?php include('header.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
        <table border="1px solid black" width='100%'>
        <tr>
            <td border="1px solid black">
                
                <br>
                <hr>
			<?php 
				include "nav.php";

					?>
					
            </td>
			
            <td>
                <table align="center" border="1px solid black">
						
 <form action="controller/updateStudent.php" method="POST" enctype="multipart/form-data">
  <label for="name">Name:</label><br>
  <input value="<?php echo $student['Name'] ?>" type="text" id="name" name="name"><br>

  <label for="username">User Name:</label><br>
  <input value="<?php echo $student['Username'] ?>" type="text" id="username" name="username"><br>
  
    <label for="password">Password:</label><br>
  <input value="<?php echo $student['Password'] ?>" type="text" id="password" name="password"><br>
  
  <label for="email">Email:</label><br>
  <input value="<?php echo $student['Email'] ?>" type="text" id="email" name="email"><br>
  
    <label for="phoneNumber">Phone Number:</label><br>
  <input value="<?php echo $student['Phone_Number'] ?>" type="text" id="phoneNumber" name="phoneNumber"><br>
  
  <label for="address">Address:</label><br>
  <input value="<?php echo $student['Address'] ?>" type="text" id="address" name="address"><br>
  
  <input type="file" name="image"><br><br>
  <input type="hidden" name="id" value="<?php echo $_GET['id'] ?>">
  <input type="submit" name = "updateStudent" value="Update">
  <input type="reset"> 
</form>  

                </table>
                
            </td>
        </tr>
    </table>
</body>
</html>

