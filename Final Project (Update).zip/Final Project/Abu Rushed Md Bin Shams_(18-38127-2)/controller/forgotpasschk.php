				<?php 
					$con=mysqli_connect('localhost','root','','eweb');
					if(isset($_POST ['search']))
					{
						$searchKey = $_POST['search'];
						$sql= "SELECT * FROM login WHERE username LIKE '$searchKey'";
						
					}
					else
					{
						$sql="SELECT * FROM login WHERE username = 'Empty'";
						
					}
					$result = mysqli_query($con,$sql);

					
				?>