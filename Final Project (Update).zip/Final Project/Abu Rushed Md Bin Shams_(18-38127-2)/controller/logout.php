<?php 
    //unset($_SESSION['flag']);
    //header('location: ../view/login.php'); 

session_start();

if (isset($_SESSION['User'])) {
	session_destroy();
	header("location:../view/login.php");
	
}

else{
	header("location:../view/login.php");
}


?>