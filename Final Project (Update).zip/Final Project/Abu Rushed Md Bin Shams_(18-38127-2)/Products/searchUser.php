
<!DOCTYPE html>
<html>
  <body>
       

        <table border="1px solid black" width='100%'>
        <tr>
            <td border="1px solid black">
                <label>Search Products</label>
                <br>
                <hr>
			<?php 
				include "nav.php";

					?>
					
            </td>
			
            <td>
                <table align="center" border="1px solid black">
						
         <form method="post" action="controller/findUser.php">
		 <br>
		<h1>SEARCH PRODUCTS	</h1>
		<input type="text" name="user_name" />
		<input type="submit" name="findUser" value="Search"/>
		</form>

                </table>
                
            </td>
        </tr>
    </table>



	

	



    <!-- [SEARCH FORM] -->



 
  </body>
</html>