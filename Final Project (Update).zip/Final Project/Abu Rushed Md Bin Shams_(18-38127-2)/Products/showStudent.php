<?php  
require_once 'controller/studentInfo.php';

$student = fetchStudent($_GET['id']);
include('./header.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<table border="1px solid black" width='100%'>

            <td border="1px solid black">
                <label></label>
                <br>
                <hr>
			<?php 
				include "nav.php";

					?>
					
            </td>
<table align="center" border="1px solid black">
<thead>
	<tr>
		<th>Product Profile</th>
		<th>Name</th>
		<th>Price</th>
		<th>Quantity</th>
		<th>Category</th>
		<th>Description</th>
		<th>Comment</th>
		<th>Image</th>
	</tr>
	</thead>
	<tbody>
	<tr>
		<td><a href="showStudent.php?id=<?php echo $student['ID'] ?>"><?php echo $student['Name'] ?></a></td>
		<td><?php echo $student['Name'] ?></td>
		<td><?php echo $student['Price'] ?></td>
		<td><?php echo $student['Quantity'] ?></td>
		<td><?php echo $student['Category'] ?></td>
		<td><?php echo $student['Description'] ?></td>
		<td><?php echo $student['Comment'] ?></td>
		<td><img width="100px" src="uploads/<?php echo $student['image'] ?>" alt="<?php echo $student['Name'] ?>"></td>
	</tr>

</table>
</table>


</body>
</html>
<?php include('./footer.php'); ?>