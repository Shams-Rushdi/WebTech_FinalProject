<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
		table,td,th{
			border:1px solid black;
		}
	</style>
</head>
<body>
        <table border="1px solid black" width='100%'>
        <tr>                
                <br>
                <hr>        
            <td border="1px solid black">
                <label>Products Details</label>
                <br>
                <hr>
                <ul>
				<li><a href="../addCustomer.php"> Add Customer</a></li>
				<li><a href="../showAllStudents.php"> Show all Customer</a></li>
				<li><a href="../searchUser.php"> Search Customer</a></li>
                </ul>
            </td>
			
			        				
<td>
	 <table align="center" border="1px solid black">						
		<thead>
			<tr>
				<th>Products_id</th>
				<th>Name</th>
				<th>Price</th>
				<th>Quantity</th>
				<th>Category</th>
				<th>Description</th>
				<th>Comment</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($allSearchedUsers as $i => $user): ?>
				<tr>
					<td><a href="../showStudent.php?id=<?php echo $user['ID'] ?>"><?php echo $user['ID'] ?></a></td>
					<td><?php echo $user['Name'] ?></td>
					<td><?php echo $user['Price'] ?></td>
					<td><?php echo $user['Quantity'] ?></td>
					<td><?php echo $user['Category'] ?></td>
					<td><?php echo $user['Description'] ?></td>
					<td><?php echo $user['Comment'] ?></td>
					<td><a href="../editStudent.php?id=<?php echo $user['ID'] ?>">Edit</a>&nbsp<a href="deleteStudent.php?id=<?php echo $user['ID'] ?>">Delete</a></td>
				</tr>
			<?php endforeach; ?>
			

		</tbody>
					</table>                
	</td>
			</tr>
		</table>


</body>
</html>