<?php 

require_once 'controller/studentInfo.php';
$student = fetchStudent($_GET['id']);

 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
        <table border="1px solid black" width='100%'>
        <tr>
            <td border="1px solid black">
                
                <br>
                <hr>
			<?php 
				include "nav.php";

					?>
					
            </td>
			
            <td>
                <table align="center" border="1px solid black">
						
 <form action="controller/updateStudent.php" method="POST" enctype="multipart/form-data">
  <label for="name">Products Name:</label><br>
  <input value="<?php echo $student['Name'] ?>" type="text" id="name" name="name"><br>
  <label for="price">Price:</label><br>
  <input value="<?php echo $student['Price'] ?>" type="text" id="price" name="price"><br>
  <label for="quantity">Quantity:</label><br>
  <input value="<?php echo $student['Quantity'] ?>" type="text" id="quantity" name="quantity"><br>
  <label for="category">Category:</label><br>
  <input value="<?php echo $student['Category'] ?>" type="text" id="category" name="category"><br>
  <label for="description">Description:</label><br>
  <input value="<?php echo $student['Description'] ?>" type="text" id="description" name="description"><br>
  <input type="file" name="image"><br><br>
  <input type="hidden" name="id" value="<?php echo $_GET['id'] ?>">
  <input type="submit" name = "updateStudent" value="Update">
  <input type="reset"> 
</form>  

                </table>
                
            </td>
        </tr>
    </table>
</body>
</html>

