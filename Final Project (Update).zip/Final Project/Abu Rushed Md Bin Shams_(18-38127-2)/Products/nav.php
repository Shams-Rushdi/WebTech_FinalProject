<table border="1px solid black" width='100%'>
        <tr>
            <td border="1px solid black">
                <label>Add Products</label>
                <br>
                <hr>
                <ul>
				<li><a href="../view/dashboard.php"> DashBoard</a></li>
				<li><a href="addCustomer.php"> Add Products</a></li>
				<li><a href="showAllStudents.php"> Show all Products</a></li>
				<li><a href="searchUser.php"> Search Products</a></li>
                </ul>
            </td>
			
			
        </tr>
    </table>