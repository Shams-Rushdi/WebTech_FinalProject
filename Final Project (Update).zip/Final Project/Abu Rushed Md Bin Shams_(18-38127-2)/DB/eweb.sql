-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 05, 2021 at 04:37 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eweb`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `mem_id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `username` varchar(30) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` varchar(12) NOT NULL,
  `profile` varchar(255) NOT NULL,
  `product` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`mem_id`, `firstname`, `lastname`, `username`, `email`, `password`, `profile`, `product`) VALUES
(14, 'user', 'user', 'user', 'user@email.com', 'user', 'default.jpg', ''),
(16, 'John', 'Smith', 'jsmith', 'jsmith@sample.com', 'jsmith', '1620441477.png', '');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `Contact_Number` varchar(30) DEFAULT NULL,
  `Address` varchar(30) DEFAULT NULL,
  `Picture` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `Email`, `Contact_Number`, `Address`, `Picture`) VALUES
('aaaaaaaaaa', 'aaaaaaaaaa', NULL, NULL, NULL, ''),
('admin', 'admin@123', 'aburushed@gmail.com', '01782394056', 'Dhaka', 'Rushdi.jpg'),
('Empty', 'Empty', 'Empty', 'Empty', 'Empty', 'Empty');

-- --------------------------------------------------------

--
-- Table structure for table `manager_user`
--

CREATE TABLE `manager_user` (
  `id` int(10) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Surname` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `PhoneNumber` varchar(30) NOT NULL,
  `DateOfBirth` varchar(30) NOT NULL,
  `Gender` varchar(30) NOT NULL,
  `Address` varchar(30) NOT NULL,
  `VoterIdCard` varchar(30) NOT NULL,
  `BloodGroup` varchar(30) NOT NULL,
  `Salary` varchar(30) NOT NULL,
  `image` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `manager_user`
--

INSERT INTO `manager_user` (`id`, `Name`, `Surname`, `username`, `password`, `Email`, `PhoneNumber`, `DateOfBirth`, `Gender`, `Address`, `VoterIdCard`, `BloodGroup`, `Salary`, `image`) VALUES
(1, 'asd', 'asd', 'asdf', 'asdf', 'asd', 'asd', 'asd', 'asd', 'asd', 'asd', 'asd', 'asd', 'asd');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(20) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `Dob` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `Name`, `Email`, `Username`, `Password`, `gender`, `Dob`) VALUES
(1, 'shams', 'abur@gmail.com', 'rush', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `ID` int(11) NOT NULL,
  `Name` varchar(40) NOT NULL,
  `Surname` varchar(40) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `PhoneNumber` varchar(30) DEFAULT NULL,
  `Hire_Date` varchar(30) DEFAULT NULL,
  `Gender` varchar(30) DEFAULT NULL,
  `Address` varchar(30) DEFAULT NULL,
  `VoterIdCard` varchar(30) DEFAULT NULL,
  `BloodGroup` varchar(20) DEFAULT NULL,
  `Salary` int(20) DEFAULT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`ID`, `Name`, `Surname`, `username`, `password`, `Email`, `PhoneNumber`, `Hire_Date`, `Gender`, `Address`, `VoterIdCard`, `BloodGroup`, `Salary`, `image`) VALUES
(3, 'werw', 'werewr', 'ewrw', '$2y$12$GccsOE4o9OGN5VbC93LMMezZqBsgf7gBP', 'werwe', 'werwr', 'werw', 'wer', 'werwr', 'werwerwr', NULL, NULL, 'grp.PNG'),
(4, 'rus', 'sdf', 'sdf', '$2y$12$jNy3GRC/SVkMxuQdW/Ftu.CVYuqMuJag4', 'asdasd', 'asdads', 'asdads', 'Male', 'asdasd', 'asdasda', NULL, NULL, 'dCapture.PNG'),
(7, 'abu Rushed', 'as', 'sd', '$2y$12$US385f13uLJVul7p.4NGYeM.hrZ0vJW8P', 'asd', 'asd', 'asd', 'Male', 'asda', 'asd', NULL, NULL, 'rushdi.jpg'),
(11, 'rushdi mmm', 'fffffff', 'ffffffff', '$2y$12$rfmRZal32fOG43MdsxvIUOGkk1y90SmQV', 'ffffffff', 'ffffffff', 'ffffff', 'Male', 'fffffffff', 'ffffff', 'B+', 104244, 'WIN_20200809_13_45_07_Pro.jpg'),
(14, 'rushdi', 'rtyrty', 'admin', '$2y$12$/j0SYTKO9gijoaWggudtXOaPOM/QBhqZ3', 'aburushed@gmail.com', 'sdfsdfsf', 'asdad', 'Male', 'asdasda', 'asdada', 'asdasd', 2000000, ''),
(15, 'rushdi', 'rushdi', 'admin', '$2y$12$Y6U1V/Mj3qIqXqeC1YqvbuzCLNnDaBxxF', 'aburushed@gmail.com', 'dfgdg', 'dfg', 'Male', 'dfg', 'dfg', 'A+', 20000, ''),
(16, 'Abu', 'Rushed', 'admin', '$2y$12$Wk.Jy.P1aUIijXz4ePki8OqeSZkJmEUWQ', 'asdasda', 'asdasdad', '2021-08-11', 'Male', 'asdasd', 'asdasd', 'O-', 2000, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`mem_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `manager_user`
--
ALTER TABLE `manager_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `mem_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
