-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 16, 2021 at 09:13 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test2`
--

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `Price` int(20) NOT NULL,
  `last_name` int(20) DEFAULT NULL,
  `Category` varchar(20) DEFAULT NULL,
  `Description` varchar(30) DEFAULT NULL,
  `Comment` varchar(20) DEFAULT NULL,
  `Image` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `first_name`, `Price`, `last_name`, `Category`, `Description`, `Comment`, `Image`) VALUES
(1, 'Samsung ', 9000, 10, 'Andriod', 'Samsung j7', 'Empty', NULL),
(2, 'Samsung', 10000, 20, 'Andriod', 'Samsung j5', 'comment', 'image'),
(3, 'Oppo', 20000, 20, 'Andriod', 'Oppo A6', '2022', NULL),
(4, 'Iphone', 80000, 50, 'Iphone', 'Iphone 10', 'year 2020', NULL),
(5, 'Xiaomi', 20000, 20, 'Andriod', 'Xiaomi note 8', 'year 2020', NULL),
(6, 'Xiaomi', 10000, 10, 'Andriod', 'Xiaomi note 6', 'year 2020', NULL),
(7, 'Oppo', 25000, 25, 'Andriod', 'New Product 2022', 'year 2020', NULL),
(8, 'Huawei', 23000, 23, 'Andriod', 'Huawei A5', 'year 2020', NULL),
(9, 'Huawei', 20000, 50, 'Andriod', 'Samsung j5', 'year 2020', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
