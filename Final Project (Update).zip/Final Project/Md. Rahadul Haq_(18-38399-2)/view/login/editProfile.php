<?php  
require_once '../../controller/profile/credential.php';

$product = LoginInfoLogin();



?>

<?php   

    if (isset($_SESSION['uname'])) {
        //header("location:login.php");

        $data = LoginInfoLogin();


        
            if($data["Username"] == $_SESSION['uname'])
             {
                $name = $data["Name"];
                $email = $data["Email"];
                $dob = $data["Dob"];
                $id = $data["registration_id"];
                
             } 
         
 
    }

    
    
    else{
        header("location:login.php");
    }

?>  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>



</style>
</head>
<body>
<div class="dashboard">

    

    <div class="dashboard_2">
    <form action="../../controller/profile/updateProfile.php" method="POST" enctype="multipart/form-data">
        <fieldset style="width: 500px; ">
            <legend><b>EDIT PROFILE <?php echo $bb?></b></legend><br>
            Name: <input type="text" name="name" value="<?php echo $name?>">
            <hr style="border: 0.1px solid #635C5C;;">
            Email: <input type="text" name="email" value="<?php echo $email?>">
            <hr style="border: 0.1px solid #635C5C;">
                Gender: 
                <input type="radio" id="male" name="gender" value="male" checked>Male
                <input type="radio" id="female" name="gender" value="female">Female
                <input type="radio" id="other" name="gender" value="other">Other
            <hr style="border: 0.1px solid #635C5C;;">
                Date of Birth
                <input type="text" name="dob"   size="2" value="<?php echo $dob?>">  
            <hr style="border: 0.1px solid #635C5C;"><br>
            <input type="hidden" name="id" value="<?php echo $id ?>">
            <input type="submit" name="updateProfile">
   
        </fieldset>
    </form>
    </div>
 
</div>
    
</body>
</html>
