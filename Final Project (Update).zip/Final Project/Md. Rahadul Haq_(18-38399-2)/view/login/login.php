<?php include 'head.php';?>
<?php  
require_once '../../controller/profile/credential.php';

$product = LoginInfoLogin();



?>
<?php 
    $username=$product['Username'];
    $password=$product['Password'];


    if (isset($_POST['uname'])) {
        if ($_POST['uname']==$username && $_POST['pass']==$password  ){
            $_SESSION['uname'] = $username;
            $_SESSION['pass'] = $password;
            
            if($_POST['remember'] ){
                $_SESSION['remember'] = "checked";
            }
            else{
                $_SESSION['remember'] = "";
            }
            header("location:welcome.php");
        }
        else{
            $msg="*username or password is invalid";
        }

    }
 ?>

 
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="login.css">
</head>
<body>
<div>
    <div class="modal_container" id="modal_containers">
        <div class="mod">
            <h1>Models are cool</h1>
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Recusandae earum tenetur molestias cum veritatis autem nesciunt consequuntur voluptatibus perspiciatis aliquam iusto quia eum temporibus dignissimos rerum sit, hic blanditiis debitis?</p>
            <button id="close">Close</button>
        </div>
    </div>
</div>

    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
        <div class="login_container">
            <h3>Login</h3>
            <?php if(isset($msgs)) echo $msgs;?>
            <p>Username:</p> <input type="text" name="uname" value = "<?php if(isset($_COOKIE["uname"])) {echo $_COOKIE["uname"] ; }?>">
            <p>Password:</p> <input type="password" name="pass" value ="<?php if(isset($_COOKIE["pass"])) {echo $_COOKIE["pass"] ; }?>">
            <?php if(isset($msg)) echo "<span class='error'>$msg</span>"?><br>
            <input type="checkbox" name="remember"> Remember Me <br><br>
            <button type="submit">Login</button>
            <a href="./forgotPassword.php">Forgot Password</a>
            <br><br>
        </div>
    </form>
</div>


    <script>
        const open = document.getElementById('open');
        const modal_containers = document.getElementById('modal_containers');
        const close = document.getElementById('close');

        open.addEventListener('click',() => {
          modal_containers.classList.add('show');
        });
        close.addEventListener('click',() => {
          modal_containers.classList.remove('show');
        });
    </script>

</body>
</html>

<?php include 'footer.php';?>