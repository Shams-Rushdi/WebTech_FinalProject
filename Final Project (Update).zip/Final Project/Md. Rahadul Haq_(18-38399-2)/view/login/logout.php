<?php include 'head.php';?>

<?php 

session_start();

if (isset($_SESSION['uname'])) {
	session_destroy();
	header("location:login.php");
	
}

else{
	header("location:login.php");
}

 ?>
 <?php include 'footer.php';?>