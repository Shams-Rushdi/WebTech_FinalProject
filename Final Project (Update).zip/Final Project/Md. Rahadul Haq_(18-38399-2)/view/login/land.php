<?php  
require_once '../../controller/products/productInfo.php';

$products = fetchAllProducts();



?>
<?php include 'head.php';?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  transition: 0.3s;
  width: 300px;
  padding: 2px 16px;
}

.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
}

.containers {
  padding: 2px auto;
}
</style>
</head>
<body>

<h2>Card</h2>
<div>
<?php foreach ($products as $i => $products): ?>
<div class="card">
    <img width="100px" src="../../uploads/<?php echo $products['image'] ?>" alt="<?php echo $products['Name'] ?>">  
  <div class="containers">
    <h4><b><?php echo $products['Name'] ?></b></h4> 
    <p><?php echo $products['Price'] ?> </p> 
    
    <button type="submit"><a href="../products/showProductForCustomer.php?id=<?php echo $products['Product_id'] ?>">Show Details</a></button>
  </div>
</div>
<?php endforeach; ?>
</div>
</body>
</html> 
<?php include 'footer.php';?>