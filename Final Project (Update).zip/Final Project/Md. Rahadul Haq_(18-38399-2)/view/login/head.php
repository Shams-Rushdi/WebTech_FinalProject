<?php

session_start();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="head.css">
</head>
<body>
    <div class="main_container">
        <!-- top nav start  -->
        <div class="top_nav_container">
            <div class="top_nav_left">
                <p><i class="icon-flag-checkered"></i> English <i class="icon-sort-down"></i></p>
                <p>$ USD</p>
                <p><i class="icon-phone"> +880 5327 643</i></p>
            </div>
            <div class="top_nav_right">
                <a href=""><?php  if(isset($_SESSION['uname'])) echo ""; else echo "My Account";?></a>
                <a href=""><?php  if(isset($_SESSION['uname'])) echo ""; else echo "Wishlist";?></a>
                <a href=""><?php  if(isset($_SESSION['uname'])) echo ""; else echo "My Cart";?></a>
                <a href=""><?php  if(isset($_SESSION['uname'])) echo ""; else echo "Checkout";?></a>
                <a href="">
                  <?php  
                      if(isset($_SESSION['uname'])){
                        echo "<i class='icon-user' style='color: #ff6666;'></i> ";
                        echo $_SESSION['uname'];
                        echo "<a href='./logout.php'>Logout</a>";
                      }
                      else
                      {
                        echo "<a href='./login.php'>Login</a>";
                      }
                  ?>
                </a>
          </div>
        </div>
        <!-- top nav start  -->
      
        <!-- second nav start  -->
       
            
            <?php  
            
            if(!isset($_SESSION['uname'])) echo " <div class='second_nav_container'><div class='logo' onclick='location.href='land.php''>
            <div class='logo_icon'>
                <i class='icon-shopping-cart icon'></i>
            </div>
            <div class='logo_text'>
                <h2>Kena<span>Kata</span></h2>
                <p>YOUR TRUSTED SHOP</p>
            </div>
        </div>
        <div class='search'>
              <div class='search_input'>
                  <input type='text' placeholder='Search your product'> 
              </div>
              <div class='search_icon'>
                  <i class='icon-search'></i> 
              </div>
          </div>
          <div class='shopping_cart'>
              <div class='shopping_cart_icon'>
                  <i class='icon-shopping-cart'></i> <sup>2</sup>
              </div>
              <div class='shopping_cart_text'>
                  <p>Shopping Cart</p>
              </div>
              </div></div>";
            
            ?>
        
        <!-- second nav end  -->

        <!-- third nav start  -->
        <?php 
        
        if(!isset($_SESSION['uname'])) echo "<div class='third_nav_container'>
        <a href=''>Home</a>
        <a href=''>Men</a>
        <a href=''>Women</a>
        <a href=''>Kids</a>
        <a href=''>Sports</a>
        <a href=''>Digital</a>
        <a href=''>Furniture</a>
        <a href=''>Electronics</a>
    </div>"
        
        ?>
        <!-- third nav end  -->
    </div>
</body>
</html>




<!-- --------------------------------------------------------------------------------------------------------------------------
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="head.css">
</head>
<body>


<div class="container">
  <div class="icon">
    <img src="./logo.png"  alt="E-Commerce" width="200px">
  </div>
  <div class="nav-bar">
    <ul>
      <li><a href="land.php">Home</a></li>
      <li><a href="#news"><?php  
       
       if(isset($_SESSION['uname'])){
        echo $_SESSION['uname'];
      }
      else
      {
        echo "<a href='./login.php'>Login</a>";
      }
      
      
      ?></a></li>
      <li><?php  
       
       if(isset($_SESSION['uname'])){
       echo "<a href='./logout.php'>Logout</a>";
       
      }
      else
      {
        echo "<a href='./registration.php'>Registration</a>";
        
      }
      
      
      ?></li>
    </ul>
  </div>
  
</div>


</body>
</html> -->
