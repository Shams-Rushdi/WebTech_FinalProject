<?php  
require_once '../../controller/employees/employeeInfo.php';

$employees = fetchEmployee($_GET['id']);


    



?>
<?php include '../login/head.php'?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
    <link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
	<link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.no-icons.min.css" rel="stylesheet">
	<link rel="stylesheet" href="../login/head.css">
	<style>
		body{
      font-family:"Book Antiqua";
    }
      .middle{
        border: 1px solid red;
        height: 450px;
        width: 50%;
        margin: auto;
        margin-top: 50px;
      }
      .top{
        text-align: center;
        border-bottom: 1px solid red;
        background-color: #ff6666;
		display: flex;
        color: #fff;
		justify-content: space-between;
		padding: 0 30px;
      }
      .bottom{
        height: 300px;
        padding: 20px;
		display: flex;
      }
	  .image{
		  width: 50%;
		  border: 1px solid red;
	  }
	  .info{
		  width: 50%;
		  border: 1px solid red;
		  padding: 40px;
	  }
	  .arrow_icon{
		  padding-top: 20px;
		  cursor: pointer;
	  }
	  .arrow_icon:hover{
		  color: #000;
		  transition: .3s;
	  }
  </style>
</head>
<body>

<div class="middle">
        <div class="top">
			<div class="arrow_icon"  onclick="window.location='../login/welcome.php'">
				<i class="icon-arrow-left"></i>
			</div>
            <h3>Product details</h3>
        </div>
        <div class="bottom">
	  		<div class="image">
			  <img  src="../../uploads/<?php echo $employees['Image'] ?>" alt="<?php echo $employees['Name'] ?>">
			</div>
			<div class="info">
	  			<h3>Name : <?php echo $employees['Name'] ?></h3>
				<h5>Category : <?php echo $employees['Gender'] ?></td></h5>
	  			<h4>Price : <?php echo $employees['Salary'] ?></h4>
	  			<p>Commission : <?php echo $employees['Commission'] ?></p>
	  			<p>Birth date : <?php echo $employees['Dob'] ?></p>
	  			<p>Phone no : <?php echo $employees['Phone_no'] ?></p>
	  			<p>Address : <?php echo $employees['Address'] ?></p>
	  			<p>Image : <?php echo $employees['Image'] ?></p>
			</div>
        </div>
      </div>
</body>
</html>