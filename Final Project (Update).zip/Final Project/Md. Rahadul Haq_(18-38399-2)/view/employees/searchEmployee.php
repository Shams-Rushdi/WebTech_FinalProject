
<!DOCTYPE html>
<html>
  <body>

    <!-- [SEARCH FORM] -->
    <form method="post" action="../../controller/employees/findEmployee.php">
      <h1>SEARCH FOR PRODUCTS</h1>
      <input type="text" name="name" />
      <input type="submit" name="findEmployee" value="Search"/>
    </form>


 
  </body>
</html>