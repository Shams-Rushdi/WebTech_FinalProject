
 <form action="../../controller/employees/createEmployee.php" method="POST" enctype="multipart/form-data">
  <label for="name">Name:</label><br>
  <input type="text" id="Name" name="name"><br>
  <label for="surname">Gender:</label><br>
  <input type="text" id="Gender" name="gender"><br>
  <label for="username">Salary:</label><br>
  <input type="number" id="Salary" name="salary"><br>
  <label for="text">Hire date:</label><br>
  <input type="text" id="Hire_date" name="hire_date"><br>
  <label for="text">Commission:</label><br>
  <input type="text" id="Commission" name="commission"><br> 
  <label for="text">Classification:</label><br>
  <input type="text" id="Commission" name="classification"><br>
  <label for="text">Date of birth:</label><br>
  <input type="text" id="Dob" name="dob"><br>
  <label for="text">Phone no:</label><br>
  <input type="text" id="Phone-_no" name="phone_no"><br>
  <label for="text">Address:</label><br>
  <input type="text" id="Address" name="address"><br>
  <input type="file" name="image"><br><br>
  <input type="submit" name = "createEmployee" value="Create">
  <input type="reset"> 
</form> 


