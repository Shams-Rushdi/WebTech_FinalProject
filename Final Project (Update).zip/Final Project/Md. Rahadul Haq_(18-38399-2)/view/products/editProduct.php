<?php 

require_once '../../controller/products/productInfo.php';
$product = fetchProduct($_GET['id']);


 ?>

<?php include '../login/head.php'?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
  <link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.no-icons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../login/head.css">
  <style>
    body{
      font-family:"Book Antiqua";
    }
      .middle{
        border: 1px solid red;
        height: 450px;
        width: 50%;
        margin: auto;
        margin-top: 50px;
      }
      .top{
        text-align: center;
        border-bottom: 1px solid red;
        background-color: #ff6666;
        color: #fff;
        justify-content: space-between;
        padding: 0 30px;
        display: flex;
      }
      .bottom{
        overflow: auto;
        height: 300px;
        padding: 20px;
      }
      .arrow_icon{
        padding-top: 20px;
        cursor: pointer;
      }
      .arrow_icon:hover{
        color: #000;
      }
  </style>
</head>
<body>
      <div class="middle">
        <div class="top">
            <div class="arrow_icon"  onclick="window.location='../login/welcome.php'">
                <i class="icon-arrow-left"></i>
          </div>
            <h3>Edit product</h3>
        </div>
        <div class="bottom">
          <form action="../../controller/products/updateProduct.php" method="POST" enctype="multipart/form-data">
            <label for="name">Name:</label><br>
            <input value="<?php echo $product['Name'] ?>" type="text" id="name" name="name"><br>
            <label for="surname">Price:</label><br>
            <input value="<?php echo $product['Price'] ?>" type="text" id="surname" name="price"><br>
            <label for="username">Quantity</label><br>
            <input value="<?php echo $product['Quantity'] ?>" type="text" id="username" name="quantity"><br>
            <label for="name">Category:</label><br>
            <input value="<?php echo $product['Category'] ?>" type="text" id="name" name="category"><br>
            <label for="name">Description:</label><br>
            <input value="<?php echo $product['Description'] ?>" type="text" id="name" name="description"><br>
            <input type="file" name="image"><br><br>
            <input type="hidden" name="id" value="<?php echo $_GET['id'] ?>">
            <input type="submit" name = "updateProduct" value="Update">
            <input type="reset"> 
        </form>
        </div>
      </div>

</body>
</html>


