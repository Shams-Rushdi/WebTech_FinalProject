<table>
	<thead>
		<tr>
			<th>Name</th>
			<th>Price</th>
			<th>Quantity</th>
			<th>Category</th>
			<th>Image</th>
			<th>Description</th>
			<th>Comment</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($products as $i => $products): ?>
			<tr>
				<td><?php echo $products['Name'] ?></td>
				<td><?php echo $products['Price'] ?></td>
				<td><?php echo $products['Quantity'] ?></td>
				<td><?php echo $products['Category'] ?></td>
				<td><?php echo $products['image'] ?></td>
				<td><?php echo $products['Description'] ?></td>
				<td><?php echo $products['Comment'] ?></td>
				<td><img width="100px" src="../../uploads/<?php echo $products['image'] ?>" alt="<?php echo $products['Name'] ?>"></td>
				<td><a href="../products/showProduct.php?id=<?php echo $products['Product_id'] ?>">View</a>&nbsp
				<a href="../products/editProduct.php?id=<?php echo $products['Product_id'] ?>">Edit</a>&nbsp
				<a href="../../controller/products/deleteProduct.php?id=<?php echo $products['Product_id'] ?>" onclick="return confirm('Are you sure want to delete this ?')">Delete</a></td>
			</tr>
		<?php endforeach; ?>
		

	</tbody>
	

</table>
