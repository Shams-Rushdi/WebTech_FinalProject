 <ul>
        <li><a href="../products/addProduct.php"> Add Product</a></li>
        <li><a href="../products/showAllProducts.php"> Show all Products</a></li>
        <li><a href="../products/searchProduct.php"> Search Products</a></li>
</ul>