<?php 

require_once '../../model/db_connect.php';



 ?>


<?php 


function LoginInfoLogin(){
	$conn = db_conn();
    $selectQuery = 'SELECT * FROM `registration` ';
    try{
        $stmt = $conn->query($selectQuery);
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    $rows = $stmt->fetch(PDO::FETCH_ASSOC);
    return $rows;
}
function LoginInfo(){
	$conn = db_conn();
    $selectQuery = 'SELECT * FROM `registration` ';
    try{
        $stmt = $conn->query($selectQuery);
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $rows;
}

function updateProfile($id, $data){
    $conn = db_conn();
    $selectQuery = "UPDATE registration set Name = ?, Email = ?, Username = ?, Password = ?, Gender = ?, Dob = ?, Image = ?,  where registration_id = ?";
    try{
        $stmt = $conn->prepare($selectQuery);
        $stmt->execute([
        	$data['name'], $data['email'], $data['username'], $data['password'], $data['gender'], $data['dob'],$data['image'], $id
        ]);
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    
    $conn = null;
    return true;
}

?>