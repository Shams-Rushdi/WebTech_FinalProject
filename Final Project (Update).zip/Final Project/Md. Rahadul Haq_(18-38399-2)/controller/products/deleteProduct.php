<?php 

require_once '../../model/productsModel.php';

if (deleteProduct($_GET['id'])) {
    // header('Location: ../../view/products/showAllProducts.php');
    header('Location: ../../view/login/welcome.php');
}

 ?>