<?php

require_once '../../model/productsModel.php';

if (isset($_POST['findProduct'])) {
	
		echo $_POST['name'];

    try {
    	
    	$allSearchedProducts = searchProduct($_POST['name']);
    	require_once '../../view/products/showSearchedProduct.php';

    } catch (Exception $ex) {
    	echo $ex->getMessage();
    }
}

