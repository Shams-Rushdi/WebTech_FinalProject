<?php 

require_once ('../../model/employeesModel.php');

function fetchAllEmployees(){
	return showAllEmployees();

}
function fetchEmployee($id){
	return showEmployee($id);

}
