<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
        <table border="1px solid black" width='100%'>
        <tr>
            <td border="1px solid black">
                
                <br>
                <hr>
			<?php 
				include "nav.php";
			?>
			</td>	
            <td>
 <table align="center" border="1px solid black">						
 <form action="controller/createCustomer.php" method="POST" enctype="multipart/form-data">
  <label for="name">First Name:</label><br>
  <input type="text" id="name" name="name"><br>
  <label for="surname">Lust Name:</label><br>
  <input type="text" id="surname" name="surname"><br>
  <label for="username">User Name:</label><br>
  <input type="text" id="username" name="username"><br>
    <label for="password">Password:</label><br>
  <input type="password" id="password" name="password"><br>
  <label for="email">Email:</label><br>
  <input type="text" id="email" name="email"><br>
  <label for="phoneNumber">Phone Number:</label><br>
  <input type="text" id="phoneNumber" name="phoneNumber"><br>
  <label for="hdate">Hire_Date:</label><br>
  <input type="date" id="hdate" name="hdate"><br>
   <label for="gender">Gender:</label><br>
  <input type="radio" id="male" name="gender" value="Male">
	<label for="male">Male</label><br>
	<input type="radio" id="female" name="gender" value="Female">
	<label for="female">Female</label><br>
    <label for="address">Address:</label><br>
  <input type="text" id="address" name="address"><br>
    <label for="vid">Voter Id Card:</label><br>
  <input type="text" id="vid" name="vid"><br>
    <label for="bgroup">Blood Group:</label><br>
  <select name="bgroup" id="bgroup">
		<option value="Select">Select Blood Group</option>
		<option value="A+">A+</option>
		<option value="A-">A-</option>
		<option value="B+">B+</option>
		<option value="B-">B-</option>
		<option value="AB+">AB+</option>
		<option value="AB-">AB-</option>
		<option value="O+">O+</option>
		<option value="O-">O-</option><br />
	</select> <br />
    <label for="salary">Salary:</label><br>
  <input type="text" id="salary" name="salary"><br>
  <label for="img">Image:</label><br>
  <input type="file" name="image"><br><br>
  <input type="submit" name = "createCustomer" value="Create">
  <input type="reset"> 
</form> 
                </table>                
            </td>
        </tr>
    </table>
</body>
</html>

