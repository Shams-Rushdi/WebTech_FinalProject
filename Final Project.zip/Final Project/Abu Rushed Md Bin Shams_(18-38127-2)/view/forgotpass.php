<?php include('../controller/forgotpasschk.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel='icon' href='../images/icon.png'>
    <title>Log In</title>
</head>
<body>
    <?php include('./header.php'); ?>

    <fieldset>
    <table align="right">
    <tr>
        <td>
            <nav>
                <a href="./index.php">Home</a> ||
                <a href="./login.php">Log in</a> ||
                <a href="./registration.php">Registration</a>
            </nav>
        </td>
    </tr>        
    </table>
    </fieldset>
	<br />


   	<div class="container" width='100px'>
		<div class="row">
			<div class="body" >
				<div class="row">
				<fieldset>
				<?php 
					$con=mysqli_connect('localhost','root','','eweb');
					if(isset($_POST ['search']))
					{
						$searchKey = $_POST['search'];
						$sql= "SELECT * FROM login WHERE username LIKE '$searchKey'";
						
					}
					else
					{
						$sql="SELECT * FROM login WHERE username = 'Empty'";
						
					}
					$result = mysqli_query($con,$sql);

					
				?>
				
				
	<table align="center">
		<form action="" method="POST">
			
                <legend>
                    <b>FORGOT PASSWORD</b>
                </legend>
				<table align="center">
					<div class="col-md-6">
					
					<tr>
						<td align="right">Enter Username: </td>
						<td align="right"><input type="text" name="search" class='form-control' placeholder="Search By UserName" value="" ></td> 
					</tr>
					</div>
					<tr>
                        <td colspan="2"><hr></td>
                    </tr>
					

					<div class="col-md-6 text-left">
					<tr>
					<td></td>
						<td align="right"><button class="btn">Search</button></td>

					</tr>
					</div>
	
				
				<br>
				</div>
				<table align="center">
					<tr>
						<th>username</th>
						<th>password</th>
						
					</tr>
					<?php while ($row = mysqli_fetch_object($result)){ ?>
					<tr>
						<td><?php echo $row-> username ?></td>
						<td><?php echo $row-> password ?></td>
						
					</tr>
					
					<?php } ?>
				</table>
				</table>
		</fieldset>
	</form>
</table>
		
				
			</div>
		</div>
	</div>
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
	<br />
    <?php include('./footer.php'); ?>
</body>
</html>