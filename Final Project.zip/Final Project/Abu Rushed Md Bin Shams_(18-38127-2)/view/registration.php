

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel='icon' href='./images/assets/favicon.png'>
    <title>Add a new user</title>
<script>
	function validateForm() {
	let x = document.forms["myForm"]["fname"].value;
	if (x.length < 6) {
	alert("Name must be filled out");
	document.getElementById("text").innerHTML = "Name must be filled out";
	document.getElementById("text").style.color="red";
	return false;
	}
	else{
	document.getElementById("text").innerHTML = x;
	document.getElementById("text").style.color="black";
	}
	}
	function en(){
	document.getElementById("btn").disabled = false;

	if (document.getElementById("fname").value == "" || document.getElementById("fname1").value == ""|| document.getElementById("fname2").value == ""|| document.getElementById("fname3").value == ""|| document.getElementById("fname4").value == ""|| document.getElementById("fname6").value == "") {
	document.getElementById("btn").disabled = true;
	}

	}
</script>
</head>
<body>
    <?php include('./header.php'); ?>
    
    <fieldset>
    <table align="right">
    <tr>
        <td>
            <nav>
                <a href="./index.php">Home</a> ||
                <a href="./login.php">Log in</a> ||
                <a href="./registration.php">Registration</a>
            </nav>
        </td>
    </tr>        
    </table>
    </fieldset>

    <div width='100px'>
        
		<form name="myForm" action='../controller/regcheck.php' onsubmit="return validateForm()" method="post">
            <fieldset>
                <legend>
                    <b>REGISTRATION</b>
                </legend>
                <table align="center">
                    <tr>
                        <td align="right">Name:</td>
                        <td><input type="text" id="fname" name="fname11" onkeyup="en()"></td>
                    </tr>
                    <tr>
                        <td align="right">Email:</td>
                        <td><input type="text" id="fname1" name="fname12" onkeyup="en()"></td>
                    </tr>
                    <tr>
                        <td align="right">User Name:</td>
                        <td><input type="text" id="fname2" name="fname13" onkeyup="en()"></td>
                    </tr>
                    <tr>
                        <td align="right">Password:</td>
                        <td><input type="text" id="fname3" name="fname14" onkeyup="en()"></td>
                    </tr>
                    <tr>
                        <td align="right">Confirm Password:</td>
                        <td><input type="text" id="fname4" name="fname15" onkeyup="en()"></td>
                    </tr>

                    <tr>
                        <td align="right">Gender:</td>
                        <td>
						<input type="radio" id="male" name="gender" value="male">
						<label for="male">Male</label>
						<input type="radio" id="female" name="gender" value="female">
						<label for="female">Female</label>
						<input type="radio" id="other" name="gender" value="other">
						<label for="other">Other</label>
						</td>
                    </tr>


                    <tr>
                        <td colspan="2"><hr></td>
                    </tr>
                    <tr>
                        <td align="center" colspan="2"><input id="btn" type="submit" value="Submit" disabled></td>

                    </tr>
                    <tr>
                        <td align="center" colspan="2"><input type='reset' value="Reset"></td>
                    </tr>
                </table>
            </fieldset>
        </form>
        
    </div>
    <?php include('./footer.php'); ?>
</body>
</html>