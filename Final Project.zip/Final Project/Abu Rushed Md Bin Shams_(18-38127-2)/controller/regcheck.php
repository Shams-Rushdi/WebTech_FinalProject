<?php  
 $message = '';  
 $error = '';  
    

 if(isset($_POST["submit"]))  
 {  
	 if(empty($_POST["fname11"])) 
	 {  
		$error = "Name field cannot be empty"; 
						
     }
	  
      else if(empty($_POST["fname12"]))  
      {  
           $error = "E-mail field cannot be empty";  
      }    
      else if(empty($_POST["fname13"]))  
      {  
           $error = "User Name cannot be empty";  
      } 
      else if(empty($_POST["fname14"]))  
      {  
           $error = "password cannot be empty";  
      }
      else if(empty($_POST["fname15"]))
      {
          $error = "confirm password field cannot be empty";
      }
      else if(empty($_POST["gender"]))
      {
          $error = "gender field cannot be empty";
      }
     else  
     {

     $pass = $Cpass = ""; 
     if(isset($_POST['fname14'])&&isset($_POST['fname15'])) // checking if password is set or not
     {
        $pass = $_POST['fname14'];
        $Cpass = $_POST['fname15'];
        if($pass == $Cpass) //checking if passwords match or not
        {
          
	$data['fname11'] = $_POST['fname11'];
	$data['fname12'] = $_POST['fname12'];
	$data['fname13'] = $_POST['fname13'];
	$data['fname14'] = $_POST['fname14'];
	$data['fname15'] = $_POST['fname15'];
	$data['gender'] = $_POST['gender'];


	$target_dir = "../uploads/";
	$target_file = $target_dir . basename($_FILES["image"]["name"]);

	if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
    echo "The file ". basename( $_FILES["image"]["name"]). " has been uploaded.";
  } else {
    echo "User Added With Out Profile Picture.";
  }

  if (addCustomer($data)) {
  	echo 'Successfully added!!';
  }
} 
else {
	echo 'You are not allowed to access this page.';
}


        }
        else
        {
          $error = "Passwords did not match";          
        }
    }
            
          
     }  
 
     if(isset($message))  
     {  
     echo $message;  
     }
     if(isset($error))  
     {  
          echo $error;  
     } 
     if(isset($message_1))
     {
          echo $message_1;
     }  
      
 ?> 