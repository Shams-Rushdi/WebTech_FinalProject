<?php 

require_once '../../model/employeesModel.php';

if (deleteEmployee($_GET['id'])) {
    header('Location: ../../view/login/welcome.php');


}

 ?>