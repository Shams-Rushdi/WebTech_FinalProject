<?php

require_once '../../model/employeesModel.php';

if (isset($_POST['findEmployee'])) {
	
		echo $_POST['name'];

    try {
    	
    	$allSearchedEmployees = searchEmployee($_POST['name']);
    	require_once '../../view/employees/showSearchedEmployee.php';

    } catch (Exception $ex) {
    	echo $ex->getMessage();
    }
}

