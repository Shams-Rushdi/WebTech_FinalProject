<?php  
require_once '../../model/employeesModel.php';


if (isset($_POST['updateEmployee'])) {
	$data['name'] = $_POST['name'];
	$data['gender'] = $_POST['gender'];
	$data['salary'] = $_POST['salary'];
	$data['hire_date'] = $_POST['hire_date'];
	$data['commission'] = $_POST['commission'];
	$data['classification'] = $_POST['classification'];
	$data['dob'] = $_POST['dob'];
	$data['phone_no'] = $_POST['phone_no'];
	$data['address'] = $_POST['address'];
	
	// $data['password'] = password_hash($_POST['password'], PASSWORD_BCRYPT, ["cost" => 12]);;
	$data['image'] = basename($_FILES["image"]["name"]);

	$target_dir = "../uploads/";
	$target_file = $target_dir . basename($_FILES["image"]["name"]);


  if (updateEmployee($_POST['id'], $data)) {
  	echo 'Successfully updated!!';
  	//redirect to showStudent
  	header('Location: ../../view/login/welcome.php?id=' . $_POST["id"]);
  	//header('Location: ../../view/employees/showEmployee.php?id=' . $_POST["id"]);
  }
} else {
	echo 'You are not allowed to access this page.';
}


?>