<?php 

require_once 'db_connect.php';


function addEmployee($data){
	$conn = db_conn();
    $selectQuery = "INSERT into employees (Name, Gender, Salary, Hire_date, Commission, Classification, Dob, Phone_no, Address, Image)
VALUES (:name, :gender, :salary, :hire_date, :commission, :classification, :dob, :phone_no, :address, :image)";
    try{
        $stmt = $conn->prepare($selectQuery);
        $stmt->execute([
        	':name' => $data['name'],
        	':gender' => $data['gender'],
        	':salary' => $data['salary'],
        	':hire_date' => $data['hire_date'],
        	':commission' => $data['commission'],
        	':classification' => $data['classification'],
        	':dob' => $data['dob'],
        	':phone_no' => $data['phone_no'],
        	':address' => $data['address'],
        	':image' => $data['image']

        ]);
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    
    $conn = null;
    return true;
}


function updateEmployee($id, $data){
    $conn = db_conn();
    $selectQuery = "UPDATE employees set Name = ?, Gender = ? , Salary = ? , Hire_date = ? , Commission = ? , Classification = ?, Dob = ?  Phone_no = ? , Address = ? , Image = ?  where Employee_id = ?";
    try{
        $stmt = $conn->prepare($selectQuery);
        $stmt->execute([
        	$data['name'], $data['gender'], $data['salary'], $data['hire_date'], $data['commission'], $data['classification'], $data['dob'], $data['phone_no'], $data['address'], $data['image'], $id
        ]);
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    
    $conn = null;
    return true;
}

function deleteEmployee($id){
	$conn = db_conn();
    $selectQuery = "DELETE FROM `employees` WHERE `Employee_id` = ?";
    try{
        $stmt = $conn->prepare($selectQuery);
        $stmt->execute([$id]);
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    $conn = null;

    return true;
}

function showAllEmployees(){
	$conn = db_conn();
    $selectQuery = 'SELECT * FROM `employees` ';
    try{
        $stmt = $conn->query($selectQuery);
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $rows;
}

function showEmployee($id){
	$conn = db_conn();
	$selectQuery = "SELECT * FROM `employees` where Employee_id = ?";

    try {
        $stmt = $conn->prepare($selectQuery);
        $stmt->execute([$id]);
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
    $row = $stmt->fetch(PDO::FETCH_ASSOC); /////////////////////////////////////////////////////////// Whats the needed?

    return $row;
}

function searchEmployee($name){
    $conn = db_conn();
    $selectQuery = "SELECT * FROM `employees` WHERE name LIKE '%$name%'";

    
    try{
        $stmt = $conn->query($selectQuery);
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $rows;
}


