<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.no-icons.min.css" rel="stylesheet">
    <link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
    <style>
        /* footer */

.footer{
    border: 1px solid #c3c3c3;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
    row-gap: 20px;
    padding: 30px 30px 80px;
    background-color: #333333;
    color: #fff;
}
.footer div{
    height: 200px;
    width: 250px;
}
.footer div p{
    color: rgb(165, 171, 177);
}
.footer div p:hover{
    color: rgb(240, 240, 240);
    cursor: pointer;
    font-size: 15px;
    transition: .5s;
}
.footer div i{
    color:#ff6666;
    cursor: pointer;
    transition: .5s;
}
.footer div i:hover{
    color:#fff;
    cursor: pointer;
    transition: .5s;
}
.contact .links_icon{
    justify-content: space-between;
    margin-top: 20px;
}
.contact .links_icon i{
    padding: 8px 8px;
    border: 1px solid #ff6666;
    margin-right: 10px;
}
.copyright{
    background-color: #333333;
    margin: 0;
    color: #fff;
    padding: 20px;
    text-align: center;
}

    </style>
</head>
<body>
    <div class="footer">
        <div class="main_menu">
            <h3>Main Menu</h3>
            <p>Home</p>
            <p>Our Services</p>
            <p>Our Products</p>
            <p>About Us</p>
            <p>Contact Us</p>
        </div>
        <div class="knowledge_base">
            <h3>Knowledge Base</h3>
            <p>Delivery</p>
            <p>Returns</p>
            <p>Services</p>
            <p>Discount</p>
            <p>Special Offer</p>
        </div>
        <div class="links">
            <h3>Useful Links</h3>
            <p>Site Map</p>
            <p>Search</p>
            <p>Advanced Search</p>
            <p>Suppliers</p>
            <p>FAQ</p>
        </div>
        <div class="contact">
            <h3>Contact Us</h3>
            <p>Kuril,Bishawroad,Dhaka</p>
            <p><i class="icon-phone"> </i> +880 5327 643</p>
            <p><i class="icon-envelope"> </i> kenakata@gmail.com</p>
            <div class="links_icon">
                <i class="icon-facebook"></i> 
                <i class="icon-google-plus"></i>
                <i class="icon-twitter"></i>
                <i class="icon-youtube"></i>
            </div>
        </div>
    </div>
    <p class="copyright">&copy copyright 2021</p>
</body>
</html>