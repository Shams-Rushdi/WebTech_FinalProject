<?php 

if (isset($_SESSION['uname'])) {

}

else{
	header("location:login.php");
}
?>

<!-- <?php 
require_once '../../controller/products/productInfo.php';
$product = fetchProduct($_GET['id']);
 ?> -->

<?php  
require_once '../../controller/products/productInfo.php';
$products = fetchAllProducts();
?>

<?php  
require_once '../../controller/employees/employeeInfo.php';
$employees = fetchAllEmployees(); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.no-icons.min.css" rel="stylesheet">
    <link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="dashboard.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script>
        //leftbar start
        function Product() {
            document.getElementById("showProduct").style.display = "block";
            document.getElementById("showEmployee").style.display = "none";
            document.getElementById("showSettings").style.display = "none";
        }
        function Employee() {
            document.getElementById("showEmployee").style.display = "block";
            document.getElementById("showProduct").style.display = "none";
            document.getElementById("showSettings").style.display = "none";
        }
        function Settings() {
            document.getElementById("showSettings").style.display = "block";
            document.getElementById("showEmployee").style.display = "none";
            document.getElementById("showProduct").style.display = "none";
        }
        //leftbar end

        //product start
        function AddProduct() {
            document.getElementById("addProduct").style.display = "block";
            document.getElementById("showAllProduct").style.display = "none";
            document.getElementById("searchProduct").style.display = "none";
        }
        function ShowAllProduct() {
            document.getElementById("addProduct").style.display = "none";
            document.getElementById("showAllProduct").style.display = "block";
            document.getElementById("searchProduct").style.display = "none";
        }
        function SearchProduct() {
            document.getElementById("addProduct").style.display = "none";
            document.getElementById("showAllProduct").style.display = "none";
            document.getElementById("searchProduct").style.display = "block";
        }
        function TryProduct() {
            document.getElementById("addProduct").style.display = "none";
            document.getElementById("showAllProduct").style.display = "none";
            document.getElementById("tryProduct").style.display = "block";
        }
        //product end

        //employee start
        function AddEmployee() {
            document.getElementById("addEmployee").style.display = "block";
            document.getElementById("showAllEmployee").style.display = "none";
            document.getElementById("searchEmployee").style.display = "none";
        }
        function ShowAllEmployee() {
            document.getElementById("addEmployee").style.display = "none";
            document.getElementById("showAllEmployee").style.display = "block";
            document.getElementById("searchEmployee").style.display = "none";
        }
        function SearchEmployee() {
            document.getElementById("addEmployee").style.display = "none";
            document.getElementById("showAllEmployee").style.display = "none";
            document.getElementById("searchEmployee").style.display = "block";
        }
        //employee end
        
        //profile start
        function ViewProfile() {
            document.getElementById("viewProfile").style.display = "block";
            document.getElementById("editProfile").style.display = "none";
            document.getElementById("forgotPassword").style.display = "none";
        }
        function EditProfile() {
            document.getElementById("viewProfile").style.display = "none";
            document.getElementById("editProfile").style.display = "block";
            document.getElementById("forgotPassword").style.display = "none";
        }
        function ForgotPassword() {
            document.getElementById("viewProfile").style.display = "none";
            document.getElementById("editProfile").style.display = "none";
            document.getElementById("forgotPassword").style.display = "block";
        }
        //profile end
</script>
</head>
<body>
    <div class="main_containers">
        <div class="sidebar" id="slidebar_visibility">
            <div class="panel">
                <div class="horizontal manager_top">
                    <div class="manager_top_icon">
                        <i class="icon-tasks"></i>
                    </div>
                    <div class="manager_top_text">
                        <h5>Manager Panel</h5>
                    </div>
                </div>
                <div class="horizontal manager">
                    <div class="manager_icon">
                        <i class="icon-user"></i>
                    </div>
                    <div class="manager_text">
                        <?php echo "<h5> ".$_SESSION['uname']."</h5>"; ?>
                    </div>
                </div>
            </div>
            <div class="panel_options">
                <div class="horizontal product" onclick="Product()">
                    <div class="product_icon">
                        <i class="icon-glass"></i>
                    </div>
                    <div class="product_text">
                        <h5>Product</h5>
                    </div>
                </div>
                <div class="horizontal employee" onclick="Employee()">
                    <div class="employee_icon">
                        <i class="icon-group"></i>
                    </div>
                    <div class="employee_text">
                        <h5>Employee</p>
                    </div>
                </div>
                <div class="horizontal settings" onclick="Settings()">
                    <div class="settings_icon">
                        <i class="icon-cog"></i> 
                    </div>
                    <div class="settings_text">
                        <h5>Settings</h5>
                    </div>
                </div>
            </div>
        </div>
        <!-- main content -->
        <div class="main_content">
            <div class="flex_section section1">
                <div class="flex_main_content dashboard">
                    <div class="deshboard_icon">
                        <i class="icon-arrow-left"></i>
                    </div>
                    <div class="deshboard_text">
                        <h5>Dashboard</h5>
                    </div>
                </div>
                <div class="logo" onclick="location.href='land.php'">
                    <div class="logo_icon">
                        <i class="icon-shopping-cart icon"></i>
                    </div>
                    <div class="logo_text">
                        <h4>Kena<span>Kata</span></h4>
                        <p>YOUR TRUSTED SHOP</p>
                    </div>
                </div>
            </div>
            <div class="section3">
                <div class="product_visibility"  id="showProduct">
                    <div class="top_portion">
                        <h5 onclick="AddProduct()">Add product</h5>
                        <h5 onclick="ShowAllProduct()">Show all product</h5>
                        <h5 onclick="SearchProduct()">Search product</h5>
                    </div>
                    <div class="bottom_portion">
                        <div class="productDisplay" id="addProduct">
                            <?php include '../products/addProduct.php'?>
                        </div>
                        <div class="productDisplay" id="showAllProduct">
                            <?php include '../products/showAllProducts.php'?>
                        </div>
                        <div class="productDisplay" id="searchProduct">
                            <?php include '../products/searchProduct.php'?>
                        </div>
                    </div>
                </div>
                <div class="employee_visibility" id="showEmployee">
                <div class="top_portion">
                        <h5 onclick="AddEmployee()">Add Employee</h5>
                        <h5 onclick="ShowAllEmployee()">Show all Employee</h5>
                        <h5 onclick="SearchEmployee()">Search Employee</h5>
                    </div>
                    <div class="bottom_portion">
                        <div class="productDisplay" id="addEmployee">
                            <?php include '../employees/addEmployee.php'?>
                        </div>
                        <div class="productDisplay" id="showAllEmployee">
                            <?php include '../employees/showAllEmployees.php'?>
                        </div>
                        <div class="productDisplay" id="searchEmployee">
                            <?php include '../employees/searchEmployee.php'?>
                        </div>
                    </div>
                </div>
                <div class="profile_visibility" id="showSettings"> 
                <div class="top_portion">
                        <h5 onclick="ViewProfile()">View Profile</h5>
                        <h5 onclick="EditProfile()">Edit Profile</h5>
                        <h5 onclick="ForgotPassword()">Forgot Password</h5>
                    </div>
                    <div class="bottom_portion">
                        <div class="productDisplay" id="viewProfile">
                            <?php include '../login/viewProfile.php'?>
                        </div>
                        <div class="productDisplay" id="editProfile">
                            <?php include '../login/editProfile.php'?>
                        </div>
                        <div class="productDisplay" id="forgotPassword">
                            <?php include '../login/forgotPassword.php'?>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>




