
<?php  
require_once '../../controller/profile/credential.php';

$product = LoginInfoLogin();



?>

<?php   

    if (isset($_SESSION['uname'])) {
        //header("location:login.php");

        $data = LoginInfoLogin();


        
            if($data["Username"] == $_SESSION['uname'])
             {
                $name = $data["Name"];
                $email = $data["Email"];
                $dob = $data["Dob"];
                $id = $data["registration_id"];
                
             } 
         
 
    }

    
    
    else{
        header("location:login.php");
    }

?>  







<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
</head>
<body>


<div class="dashboard">



    <div class="dashboard_2">
    <form method="post">
    <fieldset class= "view">
    <legend><b><?php $products['Password'];?></b></legend><br>
        <div class="viewInfo">
            Name: <label type="text" name="name" ><?php echo $name?>
            <hr style="border: 0.1px solid #635C5C;;">
            Email: <label type="text" name="email" ><?php echo $email?>
            <hr style="border: 0.1px solid #635C5C;">
                Gender: 
                <input type="radio" id="male" name="gender" value="male" checked>Male
                <input type="radio" id="female" name="gender" value="female">Female
                <input type="radio" id="other" name="gender" value="other">Other
            <hr style="border: 0.1px solid #635C5C;;">
                Date of Birth: 
                <label type="date" name="dob"   size="2" >  <?php echo $dob?>
            <hr style="border: 0.1px solid #635C5C;"><br>
            <a href="editProfile.php">Edit Profile</a>
        </div>
        <div class="viewPhoto">
             <img src="./user.png" width="100" class="center" alt="">
            <br><br>
            <input type="file" id="img" name="img" accept="image/*">
            
            <br><br>
        </div>
    </fieldset>
    </form>
    </div>
 
</div>

    
</body>
</html>