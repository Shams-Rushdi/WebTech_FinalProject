<?php 

require_once '../../controller/employees/EmployeeInfo.php';
$employees = fetchEmployee($_GET['id']);


 



 ?>
<?php include '../login/head.php'?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
  <link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.no-icons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../login/head.css">
  <style>
    body{
      font-family:"Book Antiqua";
    }
      .middle{
        border: 1px solid red;
        height: 450px;
        width: 50%;
        margin: auto;
        margin-top: 50px;
      }
      .top{
        text-align: center;
        border-bottom: 1px solid red;
        background-color: #ff6666;
        color: #fff;
        justify-content: space-between;
        padding: 0 30px;
        display: flex;
      }
      .bottom{
        overflow: auto;
        height: 300px;
        padding: 20px;
      }
      .arrow_icon{
        padding-top: 20px;
        cursor: pointer;
      }
      .arrow_icon:hover{
        color: #000;
      }
  </style>
</head>
<body>

<div class="middle">
    <div class="top">
        <div class="arrow_icon"  onclick="window.location='../login/welcome.php'">
            <i class="icon-arrow-left"></i>
      </div>
        <h3>Edit Employee</h3>
    </div>
    <div class="bottom">
      
        <form action="../../controller/employees/updateEmployee.php" method="POST" enctype="multipart/form-data">
          <label for="name">Name:</label><br>
          <input value="<?php echo $employees['Name'] ?>" type="text" id="name" name="name"><br>
          <label for="surname">Gender:</label><br>
          <input value="<?php echo $employees['Gender'] ?>" type="text" id="surname" name="gender"><br>
          <label for="username">Salary</label><br>
          <input value="<?php echo $employees['Salary'] ?>" type="text" id="username" name="salary"><br>
          <label for="name">Hire date:</label><br>
          <input value="<?php echo $employees['Hire_date'] ?>" type="text" id="name" name="hire_date"><br>
          <label for="name">Commission:</label><br>
          <input value="<?php echo $employees['Commission'] ?>" type="text" id="name" name="commission"><br>
          <label for="name">Classification:</label><br>
          <input value="<?php echo $employees['Classification'] ?>" type="text" id="name" name="classification"><br>
          <label for="name">Birth Date:</label><br>
          <input value="<?php echo $employees['Dob'] ?>" type="text" id="name" name="dob"><br>
          <label for="name">Phone no:</label><br>
          <input value="<?php echo $employees['Phone_no'] ?>" type="text" id="name" name="phone_no"><br>
          <label for="name">Address:</label><br>
          <input value="<?php echo $employees['Address'] ?>" type="text" id="name" name="address"><br>
          <input type="file" name="image"><br><br>
          <input type="hidden" name="id" value="<?php echo $_GET['id'] ?>">
          <input type="submit" name = "updateEmployee" value="Update">
          <input type="reset"> 
        </form> 
    </div>
  </div>


























</body>
</html>

