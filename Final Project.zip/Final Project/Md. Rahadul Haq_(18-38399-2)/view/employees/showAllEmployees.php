

<table>
	<thead>
		<tr>
			<th>Name</th>
			<th>Gender</th>
			<th>Salary</th>
			<th>Hire date</th>
			<th>Commission</th>
			<th>Date of birth</th>
			<th>Phone no</th>
			<th>Address</th>
			<th>Image</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($employees as $i => $employees): ?>
			<tr>
				<td><?php echo $employees['Name'] ?></a></td>
				<td><?php echo $employees['Gender'] ?></td>
				<td><?php echo $employees['Salary'] ?></td>
				<td><?php echo $employees['Hire_date'] ?></td>
				<td><?php echo $employees['Commission'] ?></td>
				<td><?php echo $employees['Dob'] ?></td>
				<td><?php echo $employees['Phone_no'] ?></td>
				<td><?php echo $employees['Address'] ?></td>
				<td><?php echo $employees['Image'] ?></td>
				<td><img width="100px" src="../../uploads/<?php echo $employees['Image'] ?>" alt="<?php echo $employees['Name'] ?>"></td>
				<td><a href="../employees/showEmployee.php?id=<?php echo $employees['Employee_id'] ?>">View</a>&nbsp
				<a href="../employees/editEmployee.php?id=<?php echo $employees['Employee_id'] ?>">Edit</a>&nbsp
				<a href="../../controller/employees/deleteEmployee.php?id=<?php echo $employees['Employee_id'] ?>" onclick="return confirm('Are you sure want to delete this ?')">Delete</a></td>

			</tr>
		<?php endforeach; ?>
		

	</tbody>
	

</table>
