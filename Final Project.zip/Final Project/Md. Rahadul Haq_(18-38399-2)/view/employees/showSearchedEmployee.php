<?php include '../../view/login/head.php'?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
  <link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.no-icons.min.css" rel="stylesheet">
  <link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
  <link rel="stylesheet" href="../../view/login/head.css">
  <style>
    body{
      font-family:"Book Antiqua";
    }
      .middle{
        border: 1px solid red;
        height: 400px;
        width: 50%;
        margin: auto;
        margin-top: 50px;
      }
      .top{
        text-align: center;
        border-bottom: 1px solid red;
        background-color: #ff6666;
		display: flex;
        color: #fff;
		justify-content: space-between;
		padding: 0 30px;
      }
      .bottom{
        overflow: auto;
        height: 300px;
        padding: 20px;
      }
	  .arrow_icon{
		  padding-top: 20px;
		  cursor: pointer;
	  }
	  .arrow_icon:hover{
		  color: #000;
		  transition: .3s;
	  }
  </style>
</head>
<body>
<div class="middle">
        <div class="top">
			<div class="arrow_icon"  onclick="window.location='../../view/login/welcome.php'">
				<i class="icon-arrow-left"></i>
			</div>
            <h3>Searched product</h3>
        </div>
        <div class="bottom">
<table>
	<thead>
		<tr>
			<th>User_id</th>
			<th>Name</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($allSearchedEmployees as $i => $employee): ?>
			<tr>
				<td><a href="../showProduct.php?id=<?php echo $employee['Employee_id'] ?>"><?php echo $employee['Employee_id'] ?></a></td>
				<td><?php echo $employee['Name'] ?></td>
				<td><a href="../editProduct.php?id=<?php echo $employee['Employee_id'] ?>">Edit</a> &nbsp<a href="deleteProduct.php?id=<?php echo $employee['Employee_id'] ?>">Delete</a></td>
			</tr>
		<?php endforeach; ?>
		

	</tbody>
	

</table>


</div>
      </div>

</body>
</html>