 <ul>
        <li><a href="./addEmployee.php"> Add Employee</a></li>
        <li><a href="./showAllEmployees.php"> Show all Employees</a></li>
        <li><a href="./searchEmployee.php"> Search Employee</a></li>
</ul>