

    <!-- [SEARCH FORM] -->
    <form method="post" action="../../controller/products/findProduct.php">
      <h1>SEARCH FOR PRODUCTS</h1>
      <p>Suggestions: <span id="txtHint"></span></p> 
      <input type="text" name="name" id="txt1" onkeyup="showHint(this.value)"/>
      <input type="submit" name="findProduct" value="Search"/>
    </form>

    <!-- <?php foreach ($allSearchedProducts as $i => $product): ?>
			<p><?php echo $product['Product_id'] ?></p>
		<?php endforeach; ?> -->




<!-- <script>
    function showHint(str) {
      if (str.length == 0) { 
        document.getElementById("txtHint").innerHTML = "";
        return;
      }
      const xhttp = new XMLHttpRequest();
      xhttp.onload = function() {
        document.getElementById("txtHint").innerHTML =
        this.responseText;
      }
      xhttp.open("GET", "showProduct.php?id="+str);
      xhttp.send();
    }
</script> -->
