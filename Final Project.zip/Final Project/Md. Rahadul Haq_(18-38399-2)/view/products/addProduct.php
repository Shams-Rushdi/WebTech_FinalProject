<form action="../../controller/products/createProduct.php" method="POST" enctype="multipart/form-data">
  <label for="name">Name:</label><br>
  <input type="text" id="name" name="name"><br>
  <label for="surname">Price:</label><br>
  <input type="number" id="surname" name="price"><br>
  <label for="username">Quantity:</label><br>
  <input type="number" id="username" name="quantity"><br>
  <label for="password">Category:</label><br>
  <input type="text" id="Category" name="category"><br>
  <label for="password">Description:</label><br>
  <input type="text" id="Description" name="description"><br>
  <input type="file" name="image"><br><br>
  <input type="submit" name = "createProduct" value="Create">
  <input type="reset"> 
</form> 



