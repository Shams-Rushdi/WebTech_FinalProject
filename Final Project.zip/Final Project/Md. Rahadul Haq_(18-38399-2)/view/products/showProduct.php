<?php  
require_once '../../controller/products/productInfo.php';

$product = fetchProduct($_GET['id']);


    



?>
<?php include '../login/head.php'?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
    <link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
	<link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.no-icons.min.css" rel="stylesheet">
	<link rel="stylesheet" href="../login/head.css">
	<style>
		body{
      font-family:"Book Antiqua";
    }
      .middle{
        border: 1px solid red;
        height: 450px;
        width: 50%;
        margin: auto;
        margin-top: 50px;
      }
      .top{
        text-align: center;
        border-bottom: 1px solid red;
        background-color: #ff6666;
		display: flex;
        color: #fff;
		justify-content: space-between;
		padding: 0 30px;
      }
      .bottom{
        height: 300px;
        padding: 20px;
		display: flex;
      }
	  .image{
		  width: 50%;
		  border: 1px solid red;
	  }
	  .info{
		  width: 50%;
		  border: 1px solid red;
		  padding: 40px;
	  }
	  .arrow_icon{
		  padding-top: 20px;
		  cursor: pointer;
	  }
	  .arrow_icon:hover{
		  color: #000;
		  transition: .3s;
	  }
  </style>
</head>
<body>

      <div class="middle">
        <div class="top">
			<div class="arrow_icon"  onclick="window.location='../login/welcome.php'">
				<i class="icon-arrow-left"></i>
			</div>
            <h3>Product details</h3>
        </div>
        <div class="bottom">
	  		<div class="image">
			  <img  src="../../uploads/<?php echo $product['image'] ?>" alt="<?php echo $product['Name'] ?>">
			</div>
			<div class="info">
	  			<h3>Name : <?php echo $product['Name'] ?></td></h3>
				<h5>Category : <?php echo $product['Category'] ?></td></h5>
	  			<h4>Price : <?php echo $product['Price'] ?></td></h4>
	  			<p>Description : <?php echo $product['Description'] ?></td></p>
			</div>
        </div>
      </div>

</body>



</html>


<!-- <table>
	<tr>
		<th>Name</th>
		<th>Price</th>
		<th>Qunatity</th>
		<th>Category</th>
		<th>Image</th>
		<th>Description</th>
	</tr>
	<tr>
		<td><a href="showProduct.php?id=<?php echo $product['Product_id'] ?>"><?php echo $product['Name'] ?></a></td>
		<td><?php echo $product['Price'] ?></td>
		<td><?php echo $product['Quantity'] ?></td>
		<td><?php echo $product['Category'] ?></td>
		<td><?php echo $product['image'] ?></td>
		<td><?php echo $product['Description'] ?></td>
		<td><img width="100px" src="../../uploads/<?php echo $product['image'] ?>" alt="<?php echo $product['Name'] ?>"></td>
	</tr>

</table> -->